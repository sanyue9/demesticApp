import Vue from 'vue'
import VueRouter from 'vue-router'
import Home from '@/views/Home'
import Message from '@/views/Message'
import Publish from '@/views/Publish'
import User from '@/views/User'
Vue.use(VueRouter)

const routes = [
  { path: '/', component: Home },
  { path: '/pub', component: Publish },
  { path: '/msg', component: Message },
  { path: '/user', component: User }
]

const router = new VueRouter({
  routes
})

export default router
