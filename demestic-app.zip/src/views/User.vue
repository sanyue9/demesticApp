<template>
    <div class="user-container">
         <!--标题部分-->
            <van-nav-bar
            fixed
            title="个人中心"
            />

        <div class="card">
            <!--用户部分-->
                 <van-cell>
                       <template #icon>
                        <van-image
                        class="pc"
                        src="https://img0.baidu.com/it/u=1077360284,2857506492&fm=26&fmt=auto"
                        width="15vw"
                        round
                        ></van-image>
                    </template>

                    <template #title>
                        <span><h4>三月</h4></span>
                    </template>
                 </van-cell>
        </div>
        <OrderMe></OrderMe>
        <Order></Order>
        <Offer></Offer>
        <Finding></Finding>
    </div>
</template>

<script>
import Finding from '@/userComponent/Finding'
import Offer from '@/userComponent/Offer'
import OrderMe from '@/userComponent/OrderMe'
import Order from '@/userComponent/Order'
export default {
  components: {
    Finding,
    Offer,
    OrderMe,
    Order
  }
}
</script>

<style lang="less" scoped>
// 标题样式
.user-container {
    padding-top: 46px;
    padding-bottom: 50px;
       .van-nav-bar{
         background-color:#EDD176;

       /deep/.van-nav-bar__title {
            font-weight: bold;
        }
    }

}

//用户样式
.card {
    text-align: left;
    padding:2vw;
    height: 12vh;
    background-color: #EDD176;

    .van-cell{
        background-color: #EDD176;
    }
}

.pc{
    margin-right: 2vw;
}
</style>
