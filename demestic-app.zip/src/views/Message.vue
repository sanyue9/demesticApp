<template>
    <div>
        msg
    </div>
</template>

<script></script>

<style lang="less" scoped></style>
