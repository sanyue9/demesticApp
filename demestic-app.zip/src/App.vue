<template>
<div class="dem-container">
  <router-view></router-view >
  <van-tabbar
  route
  active-color="#F2D065" inactive-color="#808080">
  <van-tabbar-item to="/" icon="home-o">广场</van-tabbar-item>
  <van-tabbar-item to="/pub" icon="records">发布</van-tabbar-item>
  <van-tabbar-item to="/msg" icon="chat-o">消息</van-tabbar-item>
  <van-tabbar-item to="/user" icon="user-o">我的</van-tabbar-item>
</van-tabbar>
</div>
</template>

<script>

export default {

}
</script>

<style scoped>
.dem-container{
  text-align: center;
  background-color: rgb(250, 250, 250);
}
</style>
